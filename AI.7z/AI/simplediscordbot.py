import discord
from discord.ext import commands

bot = commands.Bot(command_prefix='!')

@bot.event
async def on_ready():
    print(f'We have logged in as {bot.user}')

@bot.command()
async def hello(ctx):
    await ctx.send('Hello!')

bot.run('MTE2NDIzNjYzNjIzNDcxOTM2Mg.GmL28w.lP23T1TbBW9yf4coZEfFHuQMWcgUtcWeMgP7IY')